var convert = require('./convert'),
    func = convert('forEach', require('../forEach'));

func.placeholder = require('./placeholder');
module.exports = func;
