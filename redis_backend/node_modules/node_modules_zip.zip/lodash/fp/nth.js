var convert = require('./convert'),
    func = convert('nth', require('../nth'));

func.placeholder = require('./placeholder');
module.exports = func;
