var convert = require('./convert'),
    func = convert('now', require('../now'), require('./_falseOptions'));

func.placeholder = require('./placeholder');
module.exports = func;
