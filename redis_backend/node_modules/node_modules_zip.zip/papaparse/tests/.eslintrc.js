module.exports = {
	"extends": ["../.eslintrc.js"],
	"parserOptions": {
		"ecmaVersion": 8
	},
	"env": {
		"mocha": true
	},
	"rules": {

	}
};
