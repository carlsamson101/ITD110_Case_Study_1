# @redis/client

The source code and documentation for this package are in the main [node-redis](https://github.com/redis/node-redis) repo.
